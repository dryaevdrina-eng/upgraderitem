package com.example.upgradecases.command;

import com.example.upgradecases.util.JackpotManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Collection;
import java.util.List;

/**
 * /jackpot — следующий открытый кейс гарантированно даст джекпот.
 * /jackpot <игроки> — то же для указанных игроков.
 * Работает только с правами оператора (уровень 2+) или при включённых читах.
 */
public final class JackpotCommand {
    private JackpotCommand() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("jackpot")
                        // Уровень 2: оператор на сервере либо одиночная игра с читами.
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(context -> arm(context.getSource(), List.of(context.getSource().getPlayerOrThrow())))
                        .then(CommandManager.argument("targets", EntityArgumentType.players())
                                .executes(context -> arm(context.getSource(),
                                        EntityArgumentType.getPlayers(context, "targets"))))));
    }

    private static int arm(ServerCommandSource source, Collection<ServerPlayerEntity> players) {
        for (ServerPlayerEntity player : players) {
            JackpotManager.arm(player);
            if (source.getEntity() != player) {
                player.sendMessage(Text.translatable("msg.upgradecases.jackpot_armed"), false);
            }
        }
        int count = players.size();
        source.sendFeedback(() -> Text.translatable("commands.upgradecases.jackpot", count), true);
        return count;
    }
}
