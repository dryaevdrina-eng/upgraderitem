package com.example.upgradecases.util;

import com.example.upgradecases.UpgradeCasesMod;
import com.example.upgradecases.item.CaseTier;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Логика улучшения предмета:
 *  1) бонус к атрибуту (урон у оружия/инструментов, броня у брони);
 *  2) повышение уровней зачарований из пула, подходящего этому типу предмета
 *     (кирка -> Эффективность, Удача и т.д.), но не выше ванильного максимума.
 */
public final class ItemUpgrader {
    private ItemUpgrader() {}

    /** Зачарование из пула: id и максимальный (ванильный) уровень. */
    private record Ench(String id, int max) {}

    private static Ench e(String id, int max) { return new Ench(id, max); }

    // Пулы зачарований по типам предметов (взаимоисключающие чары намеренно не смешиваем).
    private static final List<Ench> POOL_PICKAXE = List.of(e("efficiency", 5), e("unbreaking", 3), e("fortune", 3), e("mending", 1));
    private static final List<Ench> POOL_AXE = List.of(e("sharpness", 5), e("efficiency", 5), e("unbreaking", 3), e("fortune", 3), e("mending", 1));
    private static final List<Ench> POOL_SHOVEL = List.of(e("efficiency", 5), e("unbreaking", 3), e("fortune", 3), e("mending", 1));
    private static final List<Ench> POOL_HOE = POOL_SHOVEL;
    private static final List<Ench> POOL_SWORD = List.of(e("sharpness", 5), e("looting", 3), e("fire_aspect", 2),
            e("sweeping_edge", 3), e("knockback", 2), e("unbreaking", 3), e("mending", 1));
    private static final List<Ench> POOL_HELMET = List.of(e("protection", 4), e("respiration", 3), e("aqua_affinity", 1),
            e("thorns", 3), e("unbreaking", 3), e("mending", 1));
    private static final List<Ench> POOL_CHEST = List.of(e("protection", 4), e("thorns", 3), e("unbreaking", 3), e("mending", 1));
    private static final List<Ench> POOL_LEGS = List.of(e("protection", 4), e("swift_sneak", 3), e("thorns", 3),
            e("unbreaking", 3), e("mending", 1));
    private static final List<Ench> POOL_BOOTS = List.of(e("protection", 4), e("feather_falling", 4), e("depth_strider", 3),
            e("thorns", 3), e("unbreaking", 3), e("mending", 1));
    private static final List<Ench> POOL_BOW = List.of(e("power", 5), e("punch", 2), e("flame", 1), e("infinity", 1), e("unbreaking", 3));
    private static final List<Ench> POOL_CROSSBOW = List.of(e("quick_charge", 3), e("piercing", 4), e("unbreaking", 3), e("mending", 1));

    private static List<Ench> poolFor(ItemStack stack) {
        Item item = stack.getItem();
        if (item instanceof PickaxeItem) return POOL_PICKAXE;
        if (item instanceof AxeItem) return POOL_AXE;
        if (item instanceof ShovelItem) return POOL_SHOVEL;
        if (item instanceof HoeItem) return POOL_HOE;
        if (item instanceof SwordItem) return POOL_SWORD;
        if (item instanceof BowItem) return POOL_BOW;
        if (item instanceof CrossbowItem) return POOL_CROSSBOW;
        if (item instanceof ArmorItem armor) {
            return switch (armor.getType()) {
                case HELMET -> POOL_HELMET;
                case CHESTPLATE -> POOL_CHEST;
                case LEGGINGS -> POOL_LEGS;
                case BOOTS -> POOL_BOOTS;
                default -> List.<Ench>of();
            };
        }
        return List.of();
    }

    private static AttributeModifiersComponent modifiersOf(ItemStack stack) {
        return stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
    }

    /** Улучшить можно оружие, инструменты, броню, лук и арбалет (и всё, что даёт урон/броню). */
    public static boolean canUpgrade(ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (!poolFor(stack).isEmpty()) return true;
        for (var entry : modifiersOf(stack).modifiers()) {
            if (entry.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE)
                    || entry.attribute().equals(EntityAttributes.GENERIC_ARMOR)) {
                return true;
            }
        }
        return false;
    }

    /** Применяет улучшение к стеку (изменяет переданный ItemStack). */
    public static void upgrade(ItemStack stack, CaseTier tier, DynamicRegistryManager registries, Random random) {
        addAttributeBonus(stack, tier.getBonus());
        addEnchantments(stack, tier.getEnchantRolls(), registries, random);
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
    }

    // ---------- бонус к атрибуту ----------
    private static void addAttributeBonus(ItemStack stack, double bonus) {
        AttributeModifiersComponent old = modifiersOf(stack);

        // Основной атрибут: урон в приоритете, иначе броня.
        RegistryEntry<EntityAttribute> targetAttr = null;
        AttributeModifierSlot targetSlot = null;
        for (var entry : old.modifiers()) {
            if (entry.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE)) {
                targetAttr = entry.attribute();
                targetSlot = entry.slot();
                break;
            }
        }
        if (targetAttr == null) {
            for (var entry : old.modifiers()) {
                if (entry.attribute().equals(EntityAttributes.GENERIC_ARMOR)) {
                    targetAttr = entry.attribute();
                    targetSlot = entry.slot();
                    break;
                }
            }
        }
        if (targetAttr == null) return; // например лук: бонуса к атрибуту нет, только зачарования

        AttributeModifiersComponent.Builder builder = AttributeModifiersComponent.builder();
        int level = 0;
        for (var entry : old.modifiers()) {
            builder.add(entry.attribute(), entry.modifier(), entry.slot());
            if (entry.modifier().id().getNamespace().equals(UpgradeCasesMod.MOD_ID)) level++;
        }
        level++;

        builder.add(targetAttr,
                new EntityAttributeModifier(UpgradeCasesMod.id("upgrade_" + level), bonus,
                        EntityAttributeModifier.Operation.ADD_VALUE),
                targetSlot);

        stack.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, builder.build());
    }

    // ---------- зачарования ----------
    private record Candidate(RegistryEntry<Enchantment> entry, int level) {}

    private static void addEnchantments(ItemStack stack, int rolls, DynamicRegistryManager registries, Random random) {
        List<Ench> pool = poolFor(stack);
        if (pool.isEmpty()) return;

        Registry<Enchantment> registry = registries.get(RegistryKeys.ENCHANTMENT);

        for (int i = 0; i < rolls; i++) {
            // Кандидаты: зачарования, которые ещё не достигли максимума.
            ItemEnchantmentsComponent current =
                    stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
            List<Candidate> candidates = new ArrayList<>();
            for (Ench ench : pool) {
                Optional<RegistryEntry.Reference<Enchantment>> entry = registry.getEntry(
                        RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.ofVanilla(ench.id())));
                if (entry.isEmpty()) continue;
                int level = current.getLevel(entry.get());
                if (level < ench.max()) candidates.add(new Candidate(entry.get(), level));
            }
            if (candidates.isEmpty()) return; // всё уже на максимуме

            Candidate chosen = candidates.get(random.nextInt(candidates.size()));
            stack.addEnchantment(chosen.entry(), chosen.level() + 1);
        }
    }
}
