package com.example.upgradecases.util;

import com.example.upgradecases.UpgradeCasesMod;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;

/**
 * Логика самого улучшения предмета через компоненты 1.21.
 * Оружие/инструмент получает +урон, броня — +защиту.
 */
public final class ItemUpgrader {
    private ItemUpgrader() {}

    private static AttributeModifiersComponent modifiersOf(ItemStack stack) {
        return stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
    }

    /** Улучшить можно только то, у чего есть атрибут урона или брони. */
    public static boolean canUpgrade(ItemStack stack) {
        if (stack.isEmpty()) return false;
        for (var entry : modifiersOf(stack).modifiers()) {
            if (entry.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE)
                    || entry.attribute().equals(EntityAttributes.GENERIC_ARMOR)) {
                return true;
            }
        }
        return false;
    }

    /** Применяет улучшение к стеку (изменяет переданный ItemStack). */
    public static void upgrade(ItemStack stack, double bonus) {
        AttributeModifiersComponent old = modifiersOf(stack);

        // 1) Ищем основной атрибут: урон в приоритете, иначе броня.
        RegistryEntry<EntityAttribute> targetAttr = null;
        AttributeModifierSlot targetSlot = null;
        for (var entry : old.modifiers()) {
            if (entry.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE)) {
                targetAttr = entry.attribute();
                targetSlot = entry.slot();
                break;
            }
        }
        if (targetAttr == null) {
            for (var entry : old.modifiers()) {
                if (entry.attribute().equals(EntityAttributes.GENERIC_ARMOR)) {
                    targetAttr = entry.attribute();
                    targetSlot = entry.slot();
                    break;
                }
            }
        }
        if (targetAttr == null) return; // нечего улучшать

        // 2) Копируем старые модификаторы и считаем, сколько наших уже есть (уровень апгрейда).
        AttributeModifiersComponent.Builder builder = AttributeModifiersComponent.builder();
        int level = 0;
        for (var entry : old.modifiers()) {
            builder.add(entry.attribute(), entry.modifier(), entry.slot());
            if (entry.modifier().id().getNamespace().equals(UpgradeCasesMod.MOD_ID)) level++;
        }
        level++;

        // 3) Добавляем новый модификатор с уникальным id.
        builder.add(targetAttr,
                new EntityAttributeModifier(UpgradeCasesMod.id("upgrade_" + level), bonus,
                        EntityAttributeModifier.Operation.ADD_VALUE),
                targetSlot);

        stack.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, builder.build());
        // Блеск у улучшенных предметов.
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
    }
}
