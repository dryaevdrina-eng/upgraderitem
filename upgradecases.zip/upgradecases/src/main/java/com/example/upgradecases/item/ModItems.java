package com.example.upgradecases.item;

import com.example.upgradecases.UpgradeCasesMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

/**
 * Регистрация предметов мода.
 */
public final class ModItems {
    // Кейсы улучшения
    public static final Item CASE_COMMON = registerCase(CaseTier.COMMON, Rarity.COMMON);
    public static final Item CASE_RARE = registerCase(CaseTier.RARE, Rarity.RARE);
    public static final Item CASE_LEGENDARY = registerCase(CaseTier.LEGENDARY, Rarity.EPIC);

    // Лутовые кейсы
    public static final Item CASE_ARMOR = registerLoot(LootCaseType.ARMOR);
    public static final Item CASE_PICKAXE = registerLoot(LootCaseType.PICKAXE);
    public static final Item CASE_SWORD = registerLoot(LootCaseType.SWORD);

    private ModItems() {}

    private static Item registerCase(CaseTier tier, Rarity rarity) {
        Item item = new CaseItem(new Item.Settings().maxCount(16).rarity(rarity), tier);
        return Registry.register(Registries.ITEM, UpgradeCasesMod.id(tier.getItemName()), item);
    }

    private static Item registerLoot(LootCaseType type) {
        Item item = new LootCaseItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC), type);
        return Registry.register(Registries.ITEM, UpgradeCasesMod.id(type.getItemName()), item);
    }

    /** Предмет-кейс улучшения для тира. */
    public static Item forTier(CaseTier tier) {
        return switch (tier) {
            case COMMON -> CASE_COMMON;
            case RARE -> CASE_RARE;
            case LEGENDARY -> CASE_LEGENDARY;
        };
    }

    /** Предмет лутового кейса для типа. */
    public static Item forLootType(LootCaseType type) {
        return switch (type) {
            case ARMOR -> CASE_ARMOR;
            case PICKAXE -> CASE_PICKAXE;
            case SWORD -> CASE_SWORD;
        };
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(CASE_COMMON);
            entries.add(CASE_RARE);
            entries.add(CASE_LEGENDARY);
            entries.add(CASE_ARMOR);
            entries.add(CASE_PICKAXE);
            entries.add(CASE_SWORD);
        });
    }
}
