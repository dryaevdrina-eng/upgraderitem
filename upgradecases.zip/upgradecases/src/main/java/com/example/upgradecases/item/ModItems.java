package com.example.upgradecases.item;

import com.example.upgradecases.UpgradeCasesMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

import java.util.EnumMap;
import java.util.Map;

/**
 * Регистрация предметов мода.
 */
public final class ModItems {
    // Кейсы улучшения
    public static final Item CASE_COMMON = registerCase(CaseTier.COMMON, Rarity.COMMON);
    public static final Item CASE_RARE = registerCase(CaseTier.RARE, Rarity.RARE);
    public static final Item CASE_LEGENDARY = registerCase(CaseTier.LEGENDARY, Rarity.EPIC);

    // Лутовые кейсы: регистрируются циклом по LootCaseType
    private static final Map<LootCaseType, Item> LOOT_CASES = new EnumMap<>(LootCaseType.class);

    static {
        for (LootCaseType type : LootCaseType.values()) {
            LOOT_CASES.put(type, registerLoot(type));
        }
    }

    private ModItems() {}

    private static Item registerCase(CaseTier tier, Rarity rarity) {
        Item item = new CaseItem(new Item.Settings().maxCount(16).rarity(rarity), tier);
        return Registry.register(Registries.ITEM, UpgradeCasesMod.id(tier.getItemName()), item);
    }

    private static Item registerLoot(LootCaseType type) {
        Item item = new LootCaseItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC), type);
        return Registry.register(Registries.ITEM, UpgradeCasesMod.id(type.getItemName()), item);
    }

    /** Предмет-кейс улучшения для тира. */
    public static Item forTier(CaseTier tier) {
        return switch (tier) {
            case COMMON -> CASE_COMMON;
            case RARE -> CASE_RARE;
            case LEGENDARY -> CASE_LEGENDARY;
        };
    }

    /** Предмет лутового кейса для типа. */
    public static Item forLootType(LootCaseType type) {
        return LOOT_CASES.get(type);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(CASE_COMMON);
            entries.add(CASE_RARE);
            entries.add(CASE_LEGENDARY);
            for (LootCaseType type : LootCaseType.values()) {
                entries.add(LOOT_CASES.get(type));
            }
        });
    }
}
