package com.example.upgradecases.screen;

import com.example.upgradecases.item.CaseTier;
import com.example.upgradecases.item.ModItems;
import com.example.upgradecases.util.ItemUpgrader;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.joml.Vector3f;

/**
 * Серверная (и клиентская) логика контейнера кейса.
 *
 * Схема работы:
 *  1. Игрок кладёт предмет во входной слот и жмёт «Улучшить» (кнопка BTN_UPGRADE).
 *  2. Сервер СРАЗУ бросает кубик, списывает кейс и записывает результат в синхронизируемые
 *     свойства (OUTCOME + STATE=ROLLING). Клиент видит их и проигрывает анимацию,
 *     которая заканчивается ровно на заранее выбранном результате.
 *  3. Когда анимация закончилась, клиент шлёт BTN_FINISH. Сервер проверяет, что прошло достаточно
 *     времени, и только тогда выдаёт награду/ломает предмет. Подделать результат клиент не может —
 *     исход уже решён сервером. Если игрок закрыл экран посреди анимации — исход применяется при закрытии.
 */
public class CaseScreenHandler extends ScreenHandler {
    public static final int INPUT_SLOT = 0;
    public static final int RESULT_SLOT = 1;

    // id кнопок (ScreenHandler.onButtonClick)
    public static final int BTN_UPGRADE = 0;
    public static final int BTN_FINISH = 1;

    // индексы синхронизируемых свойств (порядок важен: OUTCOME отправляется раньше STATE)
    private static final int PROP_OUTCOME = 0; // 0 = нет, 1 = успех, 2 = неудача
    private static final int PROP_STATE = 1;

    public static final int STATE_IDLE = 0;
    public static final int STATE_ROLLING = 1;

    /** Длительность анимации на клиенте, мс. */
    public static final int ANIMATION_MS = 3500;
    /** Минимум серверных тиков до принятия BTN_FINISH (с запасом на лаги: 3500 мс = 70 тиков). */
    private static final int MIN_SERVER_TICKS = 55;

    private final CaseTier tier;
    private final Inventory caseInventory = new SimpleInventory(2);
    private final PropertyDelegate properties = new ArrayPropertyDelegate(2);

    // Данные ниже имеют значение только на сервере.
    private boolean pendingSuccess;
    private long rollStartTick;

    public CaseScreenHandler(int syncId, PlayerInventory playerInventory, CaseTier tier) {
        super(ModScreenHandlers.CASE, syncId);
        this.tier = tier;

        // Слот улучшаемого предмета: принимает только то, что можно улучшить, и блокируется во время анимации.
        this.addSlot(new Slot(caseInventory, INPUT_SLOT, 30, 58) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return isIdle() && ItemUpgrader.canUpgrade(stack);
            }

            @Override
            public boolean canTakeItems(PlayerEntity player) {
                return isIdle();
            }
        });

        // Слот результата: только забирать.
        this.addSlot(new Slot(caseInventory, RESULT_SLOT, 130, 58) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return false;
            }
        });

        // Инвентарь игрока (3 ряда) и хотбар.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 102 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 160));
        }

        this.addProperties(properties);
    }

    // ---------- геттеры для клиента ----------
    public CaseTier getTier() { return tier; }
    public int getState() { return properties.get(PROP_STATE); }
    public int getOutcome() { return properties.get(PROP_OUTCOME); }
    public boolean isIdle() { return getState() == STATE_IDLE; }

    // ---------- обработка кнопок (на сервере) ----------
    @Override
    public boolean onButtonClick(PlayerEntity player, int id) {
        if (!(player instanceof ServerPlayerEntity serverPlayer)) return false;
        return switch (id) {
            case BTN_UPGRADE -> startUpgrade(serverPlayer);
            case BTN_FINISH -> {
                boolean enoughTime = getState() == STATE_ROLLING
                        && serverPlayer.getWorld().getTime() - rollStartTick >= MIN_SERVER_TICKS;
                if (enoughTime) finishUpgrade(serverPlayer);
                yield enoughTime;
            }
            default -> false;
        };
    }

    private boolean startUpgrade(ServerPlayerEntity player) {
        if (!isIdle()) return false;

        ItemStack input = caseInventory.getStack(INPUT_SLOT);
        if (input.isEmpty() || !ItemUpgrader.canUpgrade(input)) {
            player.sendMessage(Text.translatable("msg.upgradecases.no_item"), true);
            return false;
        }
        if (!caseInventory.getStack(RESULT_SLOT).isEmpty()) {
            player.sendMessage(Text.translatable("msg.upgradecases.take_result"), true);
            return false;
        }
        if (!consumeCase(player)) {
            player.sendMessage(Text.translatable("msg.upgradecases.no_case"), true);
            return false;
        }

        // Бросаем кубик на сервере.
        pendingSuccess = player.getRandom().nextFloat() < tier.getSuccessChance();
        rollStartTick = player.getWorld().getTime();

        properties.set(PROP_OUTCOME, pendingSuccess ? 1 : 2);
        properties.set(PROP_STATE, STATE_ROLLING);

        player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLOCK_CHEST_OPEN, SoundCategory.PLAYERS, 0.8f, 1.2f);
        return true;
    }

    /** Списывает один кейс этого тира из инвентаря игрока. */
    private boolean consumeCase(ServerPlayerEntity player) {
        Item caseItem = ModItems.forTier(tier);
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(caseItem)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }

    /** Применяет заранее выбранный исход: награда + эффекты или поломка + звук. */
    private void finishUpgrade(ServerPlayerEntity player) {
        if (getState() != STATE_ROLLING) return;

        ServerWorld world = player.getServerWorld();
        ItemStack input = caseInventory.getStack(INPUT_SLOT);

        if (pendingSuccess && !input.isEmpty()) {
            // УСПЕХ: переносим улучшенную копию в слот результата.
            ItemStack upgraded = input.copy();
            ItemUpgrader.upgrade(upgraded, tier.getBonus());
            caseInventory.setStack(INPUT_SLOT, ItemStack.EMPTY);
            caseInventory.setStack(RESULT_SLOT, upgraded);

            // Фиолетовые частицы вокруг игрока (цвет #A020F0 + «ведьмины» частицы).
            world.spawnParticles(new DustParticleEffect(new Vector3f(0.627f, 0.125f, 0.941f), 1.5f),
                    player.getX(), player.getBodyY(0.5), player.getZ(), 60, 0.6, 0.8, 0.6, 0.02);
            world.spawnParticles(ParticleTypes.WITCH,
                    player.getX(), player.getBodyY(0.5), player.getZ(), 30, 0.6, 0.8, 0.6, 0.05);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
            player.sendMessage(Text.translatable("msg.upgradecases.success"), true);
        } else {
            // НЕУДАЧА: предмет ломается, играем звук поломки.
            caseInventory.setStack(INPUT_SLOT, ItemStack.EMPTY);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_ITEM_BREAK, SoundCategory.PLAYERS, 1.0f, 0.9f);
            player.sendMessage(Text.translatable("msg.upgradecases.fail"), true);
        }

        properties.set(PROP_OUTCOME, 0);
        properties.set(PROP_STATE, STATE_IDLE);
        this.sendContentUpdates();
    }

    @Override
    public void onClosed(PlayerEntity player) {
        super.onClosed(player);
        if (player instanceof ServerPlayerEntity serverPlayer) {
            // Нельзя «отменить» неудачу закрытием окна: применяем исход сейчас.
            if (getState() == STATE_ROLLING) finishUpgrade(serverPlayer);
            // Возвращаем содержимое слотов игроку (или выбрасываем, если нет места).
            this.dropInventory(player, caseInventory);
        }
    }

    // ---------- shift-клик ----------
    @Override
    public ItemStack quickMove(PlayerEntity player, int slotIndex) {
        Slot slot = this.slots.get(slotIndex);
        if (!slot.hasStack() || !slot.canTakeItems(player)) return ItemStack.EMPTY;

        ItemStack original = slot.getStack();
        ItemStack copy = original.copy();

        if (slotIndex < 2) {
            // из кейса -> в инвентарь игрока
            if (!this.insertItem(original, 2, this.slots.size(), true)) return ItemStack.EMPTY;
        } else {
            // из инвентаря -> во входной слот
            if (!this.slots.get(INPUT_SLOT).canInsert(original)
                    || !this.insertItem(original, INPUT_SLOT, INPUT_SLOT + 1, false)) {
                return ItemStack.EMPTY;
            }
        }

        if (original.isEmpty()) slot.setStack(ItemStack.EMPTY);
        else slot.markDirty();
        return copy;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }
}
