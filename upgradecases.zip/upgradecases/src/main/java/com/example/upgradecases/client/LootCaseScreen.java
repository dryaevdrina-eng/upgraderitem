package com.example.upgradecases.client;

import com.example.upgradecases.loot.CasePrize;
import com.example.upgradecases.loot.CasePrizes;
import com.example.upgradecases.screen.LootCaseScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Экран лутового кейса: рулетка из иконок предметов, замедляющаяся на выпавшем призе.
 */
public class LootCaseScreen extends HandledScreen<LootCaseScreenHandler> {
    private static final int PURPLE_RGB = 0xA020F0;
    private static final Text MUSOR_DROP =
            Text.literal("musor drop").styled(style -> style.withColor(PURPLE_RGB));

    private static final int STRIP_X = 28, STRIP_Y = 30;
    private static final int WIN_W = 120, WIN_H = 22;
    private static final int CELL_W = 24;
    private static final int CELLS = 40;
    private static final int TARGET = 34;

    private final List<CasePrize> prizes;
    private final ItemStack[] displayStacks;
    private final int[] cells = new int[CELLS]; // индексы призов в ячейках ленты

    private ButtonWidget openButton;
    private boolean animating = false;
    private boolean landed = false;
    private int landedPrize = 0;
    private long animStartMs;
    private long lastFinishAttemptMs;
    private float finalScroll;

    public LootCaseScreen(LootCaseScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = 176;
        this.backgroundHeight = 184;
        this.prizes = CasePrizes.of(handler.getCaseType());
        this.displayStacks = new ItemStack[prizes.size()];
        for (int i = 0; i < prizes.size(); i++) displayStacks[i] = prizes.get(i).createDisplayStack();
    }

    @Override
    protected void init() {
        super.init();
        this.titleX = 8;
        this.titleY = 6;
        this.playerInventoryTitleX = 8;
        this.playerInventoryTitleY = 92;

        openButton = ButtonWidget.builder(Text.translatable("gui.upgradecases.open"),
                        button -> sendButton(LootCaseScreenHandler.BTN_OPEN))
                .dimensions(this.x + 56, this.y + 58, 64, 18)
                .build();
        this.addDrawableChild(openButton);

        fillCells(new Random(handler.getCaseType().ordinal() * 17L + 3L), -1);
    }

    private void sendButton(int id) {
        if (this.client != null && this.client.interactionManager != null) {
            this.client.interactionManager.clickButton(handler.syncId, id);
        }
    }

    /** Заполняет ленту случайными призами (косметика). targetPrize >= 0 ставится в целевую ячейку. */
    private void fillCells(Random random, int targetPrize) {
        for (int i = 0; i < CELLS; i++) {
            cells[i] = randomFiller(random);
        }
        if (targetPrize >= 0) cells[TARGET] = targetPrize;
    }

    private int randomFiller(Random random) {
        // Примерно в 8% ячеек показываем джекпот-иконку для интриги.
        boolean wantJackpot = random.nextInt(100) < 8;
        for (int tries = 0; tries < 50; tries++) {
            int idx = random.nextInt(prizes.size());
            if (prizes.get(idx).jackpot() == wantJackpot) return idx;
        }
        return 0;
    }

    private void updateAnimation() {
        int state = handler.getState();
        int prize = handler.getPrizeIndex();
        long now = Util.getMeasuringTimeMs();

        if (state == LootCaseScreenHandler.STATE_ROLLING && prize >= 0 && !animating) {
            startAnimation(prize);
        }

        if (animating) {
            long elapsed = now - animStartMs;
            if (state == LootCaseScreenHandler.STATE_ROLLING
                    && elapsed >= LootCaseScreenHandler.ANIMATION_MS
                    && now - lastFinishAttemptMs > 1000) {
                lastFinishAttemptMs = now;
                sendButton(LootCaseScreenHandler.BTN_FINISH);
            }
            if (state == LootCaseScreenHandler.STATE_IDLE) {
                animating = false;
                landed = true;
            }
        }
    }

    private void startAnimation(int prize) {
        Random random = new Random();
        fillCells(random, prize);
        finalScroll = TARGET * CELL_W + CELL_W / 2f - WIN_W / 2f + (random.nextInt(13) - 6);
        landedPrize = prize;
        animating = true;
        landed = false;
        animStartMs = Util.getMeasuringTimeMs();
        lastFinishAttemptMs = animStartMs;
    }

    private float currentScroll() {
        if (animating) {
            float t = Math.min(1f, (Util.getMeasuringTimeMs() - animStartMs) / (float) LootCaseScreenHandler.ANIMATION_MS);
            float eased = 1f - (float) Math.pow(1f - t, 4);
            return finalScroll * eased;
        }
        return landed ? finalScroll : 0f;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        updateAnimation();
        Slot result = handler.getSlot(LootCaseScreenHandler.RESULT_SLOT);
        openButton.active = handler.isIdle() && !result.hasStack();

        super.render(context, mouseX, mouseY, delta);
        this.drawMouseoverTooltip(context, mouseX, mouseY);
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        int x0 = this.x, y0 = this.y, x1 = x0 + backgroundWidth, y1 = y0 + backgroundHeight;

        context.fill(x0, y0, x1, y1, 0xFF000000);
        context.fill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 0xFFC6C6C6);
        context.fill(x0 + 1, y0 + 1, x1 - 2, y0 + 3, 0xFFFFFFFF);
        context.fill(x0 + 1, y0 + 1, x0 + 3, y1 - 2, 0xFFFFFFFF);
        context.fill(x0 + 2, y1 - 3, x1 - 1, y1 - 1, 0xFF555555);
        context.fill(x1 - 3, y0 + 2, x1 - 1, y1 - 1, 0xFF555555);

        for (int i = 0; i < handler.slots.size(); i++) {
            Slot slot = handler.slots.get(i);
            int sx = x0 + slot.x - 1, sy = y0 + slot.y - 1;
            if (i == LootCaseScreenHandler.RESULT_SLOT) {
                context.fill(sx - 1, sy - 1, sx + 19, sy + 19, 0xFF000000 | PURPLE_RGB);
            }
            context.fill(sx, sy, sx + 18, sy + 18, 0xFF373737);
            context.fill(sx + 1, sy + 1, sx + 18, sy + 18, 0xFFFFFFFF);
            context.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
        }

        // Обязательная фиолетовая надпись.
        context.drawCenteredTextWithShadow(this.textRenderer, MUSOR_DROP, x0 + backgroundWidth / 2, y0 + 18, 0xFFFFFFFF);

        drawStrip(context);

        int textY = y0 + 80;
        int centerX = x0 + backgroundWidth / 2;
        if (landed) {
            CasePrize prize = prizes.get(landedPrize);
            Text name = displayStacks[landedPrize].getName().copy();
            if (prize.jackpot()) name = name.copy().styled(s -> s.withColor(PURPLE_RGB));
            context.drawCenteredTextWithShadow(this.textRenderer, name, centerX, textY,
                    prize.jackpot() ? (0xFF000000 | PURPLE_RGB) : 0xFF404040);
        } else {
            Text chance = Text.translatable("gui.upgradecases.jackpot",
                    String.format(Locale.ROOT, "%.1f", handler.getCaseType().getJackpotChance() * 100));
            context.drawCenteredTextWithShadow(this.textRenderer, chance, centerX, textY, 0xFF404040);
        }
    }

    private void drawStrip(DrawContext context) {
        int sx = this.x + STRIP_X, sy = this.y + STRIP_Y;

        context.fill(sx - 1, sy - 1, sx + WIN_W + 1, sy + WIN_H + 1, 0xFF000000);
        context.fill(sx, sy, sx + WIN_W, sy + WIN_H, 0xFF1A1A1A);

        float scroll = currentScroll();

        context.enableScissor(sx, sy, sx + WIN_W, sy + WIN_H);
        for (int i = 0; i < CELLS; i++) {
            int cx = sx + Math.round(i * CELL_W - scroll);
            if (cx + CELL_W < sx || cx > sx + WIN_W) continue;

            int prizeIdx = cells[i];
            boolean jackpot = prizes.get(prizeIdx).jackpot();
            context.fill(cx + 1, sy + 1, cx + CELL_W - 1, sy + WIN_H - 1, jackpot ? 0xFF7A1FC0 : 0xFF5A5A5A);
            context.drawItem(displayStacks[prizeIdx], cx + (CELL_W - 16) / 2, sy + (WIN_H - 16) / 2);
        }
        context.disableScissor();

        int px = sx + WIN_W / 2;
        context.fill(px - 1, sy - 3, px + 1, sy + WIN_H + 3, 0xFFFFFF55);
    }
}
