package com.example.upgradecases.item;

import com.example.upgradecases.screen.CaseScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * Предмет-кейс. ПКМ открывает GUI апгрейда.
 */
public class CaseItem extends Item {
    private final CaseTier tier;

    public CaseItem(Settings settings, CaseTier tier) {
        super(settings);
        this.tier = tier;
    }

    public CaseTier getTier() { return tier; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // GUI открывается только на сервере; клиент получит пакет открытия экрана сам.
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer) {
            serverPlayer.openHandledScreen(new ExtendedScreenHandlerFactory<Integer>() {
                /** Эти данные уходят клиенту при открытии экрана (тут — номер тира). */
                @Override
                public Integer getScreenOpeningData(ServerPlayerEntity player) {
                    return tier.ordinal();
                }

                @Override
                public Text getDisplayName() {
                    return CaseItem.this.getName();
                }

                @Override
                public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
                    return new CaseScreenHandler(syncId, inv, tier);
                }
            });
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.upgradecases.chance",
                Math.round(tier.getSuccessChance() * 100)).formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.upgradecases.bonus",
                String.valueOf(tier.getBonus())).formatted(Formatting.LIGHT_PURPLE));
        tooltip.add(Text.translatable("tooltip.upgradecases.enchants",
                tier.getEnchantRolls()).formatted(Formatting.AQUA));
    }
}
