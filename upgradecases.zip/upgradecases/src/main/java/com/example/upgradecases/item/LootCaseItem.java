package com.example.upgradecases.item;

import com.example.upgradecases.screen.LootCaseScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;
import java.util.Locale;

/** Лутовый кейс (броня / кирки / мечи). ПКМ открывает экран с рулеткой. */
public class LootCaseItem extends Item {
    private final LootCaseType type;

    public LootCaseItem(Settings settings, LootCaseType type) {
        super(settings);
        this.type = type;
    }

    public LootCaseType getType() { return type; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer) {
            serverPlayer.openHandledScreen(new ExtendedScreenHandlerFactory<Integer>() {
                @Override
                public Integer getScreenOpeningData(ServerPlayerEntity player) {
                    return type.ordinal();
                }

                @Override
                public Text getDisplayName() {
                    return LootCaseItem.this.getName();
                }

                @Override
                public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
                    return new LootCaseScreenHandler(syncId, inv, type);
                }
            });
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType tooltipType) {
        tooltip.add(Text.translatable("tooltip.upgradecases.jackpot",
                String.format(Locale.ROOT, "%.1f", type.getJackpotChance() * 100)).formatted(Formatting.LIGHT_PURPLE));
    }
}
