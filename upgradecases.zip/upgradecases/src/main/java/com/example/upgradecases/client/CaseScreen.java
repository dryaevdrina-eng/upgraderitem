package com.example.upgradecases.client;

import com.example.upgradecases.screen.CaseScreenHandler;
import com.example.upgradecases.util.ItemUpgrader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.Random;

/**
 * Клиентский экран кейса. Всё рисуется кодом (без файла текстуры GUI).
 * Содержит ленту-рулетку: ячейки «OK»/«X» прокручиваются и замедляются,
 * останавливаясь на исходе, который заранее выбрал сервер.
 */
public class CaseScreen extends HandledScreen<CaseScreenHandler> {
    // Обязательная надпись: фиолетовый #A020F0.
    private static final int PURPLE_RGB = 0xA020F0;
    private static final Text MUSOR_DROP =
            Text.literal("musor drop").styled(style -> style.withColor(PURPLE_RGB).withBold(true));

    // Геометрия ленты (относительно левого верхнего угла окна).
    private static final int STRIP_X = 28, STRIP_Y = 30;
    private static final int WIN_W = 120, WIN_H = 22;
    private static final int CELL_W = 24;
    private static final int CELLS = 40;
    private static final int TARGET = 34; // индекс ячейки, на которой остановится лента

    private ButtonWidget upgradeButton;

    // Состояние анимации (только клиент).
    private boolean[] cells = new boolean[CELLS]; // true = успех
    private boolean animating = false;
    private boolean landed = false;               // анимация закончилась, показываем результат
    private boolean lastSuccess = false;
    private long animStartMs;
    private long lastFinishAttemptMs;
    private float finalScroll;

    public CaseScreen(CaseScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = 176;
        this.backgroundHeight = 184;
    }

    @Override
    protected void init() {
        super.init();
        this.titleX = 8;
        this.titleY = 6;
        this.playerInventoryTitleX = 8;
        this.playerInventoryTitleY = 92;

        upgradeButton = ButtonWidget.builder(Text.translatable("gui.upgradecases.upgrade"),
                        button -> sendButton(CaseScreenHandler.BTN_UPGRADE))
                .dimensions(this.x + 56, this.y + 58, 64, 18)
                .build();
        this.addDrawableChild(upgradeButton);

        // Превью ленты в режиме ожидания.
        Random random = new Random(handler.getTier().ordinal() * 31L + 7L);
        for (int i = 0; i < CELLS; i++) {
            cells[i] = random.nextFloat() < handler.getTier().getSuccessChance();
        }
    }

    /** Нажатие кнопки -> пакет на сервер -> ScreenHandler.onButtonClick. */
    private void sendButton(int id) {
        if (this.client != null && this.client.interactionManager != null) {
            this.client.interactionManager.clickButton(handler.syncId, id);
        }
    }

    // ---------------- логика анимации ----------------
    private void updateAnimation() {
        int state = handler.getState();
        int outcome = handler.getOutcome();
        long now = Util.getMeasuringTimeMs();

        // Сервер начал бросок -> запускаем анимацию.
        if (state == CaseScreenHandler.STATE_ROLLING && outcome != 0 && !animating) {
            startAnimation(outcome == 1);
        }

        if (animating) {
            long elapsed = now - animStartMs;

            // Анимация закончилась: просим сервер выдать награду (повтор раз в секунду, если сервер не ответил).
            if (state == CaseScreenHandler.STATE_ROLLING
                    && elapsed >= CaseScreenHandler.ANIMATION_MS
                    && now - lastFinishAttemptMs > 1000) {
                lastFinishAttemptMs = now;
                sendButton(CaseScreenHandler.BTN_FINISH);
            }

            // Сервер подтвердил завершение (состояние вернулось в IDLE).
            if (state == CaseScreenHandler.STATE_IDLE) {
                animating = false;
                landed = true;
            }
        }
    }

    private void startAnimation(boolean success) {
        Random random = new Random();
        float chance = handler.getTier().getSuccessChance();
        for (int i = 0; i < CELLS; i++) {
            cells[i] = random.nextFloat() < chance;
        }
        cells[TARGET] = success; // целевая ячейка = реальный исход

        // Небольшой случайный сдвиг внутри ячейки, чтобы остановка выглядела «живой».
        finalScroll = TARGET * CELL_W + CELL_W / 2f - WIN_W / 2f + (random.nextInt(13) - 6);

        lastSuccess = success;
        animating = true;
        landed = false;
        animStartMs = Util.getMeasuringTimeMs();
        lastFinishAttemptMs = animStartMs;
    }

    private float currentScroll() {
        if (animating) {
            float t = Math.min(1f, (Util.getMeasuringTimeMs() - animStartMs) / (float) CaseScreenHandler.ANIMATION_MS);
            float eased = 1f - (float) Math.pow(1f - t, 4); // быстрый старт, плавное торможение
            return finalScroll * eased;
        }
        return landed ? finalScroll : 0f;
    }

    // ---------------- отрисовка ----------------
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        updateAnimation();

        Slot input = handler.getSlot(CaseScreenHandler.INPUT_SLOT);
        upgradeButton.active = handler.isIdle() && ItemUpgrader.canUpgrade(input.getStack());

        super.render(context, mouseX, mouseY, delta);
        this.drawMouseoverTooltip(context, mouseX, mouseY);
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        int x0 = this.x, y0 = this.y, x1 = x0 + backgroundWidth, y1 = y0 + backgroundHeight;

        // Чёрный фон окна с тонкой фиолетовой рамкой.
        context.fill(x0, y0, x1, y1, 0xFF000000 | PURPLE_RGB);
        context.fill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 0xFF000000);

        // Фоны слотов.
        for (int i = 0; i < handler.slots.size(); i++) {
            Slot slot = handler.slots.get(i);
            int sx = x0 + slot.x - 1, sy = y0 + slot.y - 1;
            if (i == CaseScreenHandler.RESULT_SLOT) { // фиолетовая рамка вокруг результата
                context.fill(sx - 1, sy - 1, sx + 19, sy + 19, 0xFF000000 | PURPLE_RGB);
            }
            context.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3A3A);
            context.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF101010);
        }

        // ОБЯЗАТЕЛЬНАЯ фиолетовая надпись "musor drop".
        context.drawCenteredTextWithShadow(this.textRenderer, MUSOR_DROP, x0 + backgroundWidth / 2, y0 + 18, 0xFFFFFFFF);

        drawStrip(context);

        // Строка под кнопкой: шанс или итог.
        int textY = y0 + 80;
        int centerX = x0 + backgroundWidth / 2;
        if (landed) {
            Text result = Text.translatable(lastSuccess ? "gui.upgradecases.result_success" : "gui.upgradecases.result_fail");
            context.drawCenteredTextWithShadow(this.textRenderer, result, centerX, textY,
                    lastSuccess ? (0xFF000000 | PURPLE_RGB) : 0xFFFF5555);
        } else {
            Text chance = Text.translatable("gui.upgradecases.chance",
                    Math.round(handler.getTier().getSuccessChance() * 100));
            context.drawCenteredTextWithShadow(this.textRenderer, chance, centerX, textY, 0xFFAAAAAA);
        }
    }

    /** Заголовки белым цветом, потому что фон чёрный. */
    @Override
    protected void drawForeground(DrawContext context, int mouseX, int mouseY) {
        context.drawText(this.textRenderer, this.title, this.titleX, this.titleY, 0xFFFFFFFF, false);
        context.drawText(this.textRenderer, this.playerInventoryTitle,
                this.playerInventoryTitleX, this.playerInventoryTitleY, 0xFFAAAAAA, false);
    }

    private void drawStrip(DrawContext context) {
        int sx = this.x + STRIP_X, sy = this.y + STRIP_Y;

        context.fill(sx - 1, sy - 1, sx + WIN_W + 1, sy + WIN_H + 1, 0xFF555555);
        context.fill(sx, sy, sx + WIN_W, sy + WIN_H, 0xFF1A1A1A);

        float scroll = currentScroll();

        // Обрезаем всё, что выходит за окно ленты.
        context.enableScissor(sx, sy, sx + WIN_W, sy + WIN_H);
        for (int i = 0; i < CELLS; i++) {
            int cx = sx + Math.round(i * CELL_W - scroll);
            if (cx + CELL_W < sx || cx > sx + WIN_W) continue;

            boolean win = cells[i];
            context.fill(cx + 1, sy + 1, cx + CELL_W - 1, sy + WIN_H - 1, win ? 0xFFA020F0 : 0xFF5A5A5A);
            context.drawCenteredTextWithShadow(this.textRenderer, win ? "OK" : "X",
                    cx + CELL_W / 2, sy + WIN_H / 2 - 4, 0xFFFFFFFF);
        }
        context.disableScissor();

        // Указатель по центру ленты.
        int px = sx + WIN_W / 2;
        context.fill(px - 1, sy - 3, px + 1, sy + WIN_H + 3, 0xFFFFFF55);
    }
}
