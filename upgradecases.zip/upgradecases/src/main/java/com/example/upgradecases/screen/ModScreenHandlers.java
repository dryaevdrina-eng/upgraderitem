package com.example.upgradecases.screen;

import com.example.upgradecases.UpgradeCasesMod;
import com.example.upgradecases.item.CaseTier;
import com.example.upgradecases.item.LootCaseType;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;

/**
 * Регистрация типов ScreenHandler. Extended-вариант передаёт клиенту данные (тир / тип кейса).
 */
public final class ModScreenHandlers {
    public static final ScreenHandlerType<CaseScreenHandler> CASE = Registry.register(
            Registries.SCREEN_HANDLER,
            UpgradeCasesMod.id("case"),
            new ExtendedScreenHandlerType<CaseScreenHandler, Integer>(
                    (syncId, playerInventory, tierId) ->
                            new CaseScreenHandler(syncId, playerInventory, CaseTier.byId(tierId)),
                    PacketCodecs.VAR_INT));

    public static final ScreenHandlerType<LootCaseScreenHandler> LOOT_CASE = Registry.register(
            Registries.SCREEN_HANDLER,
            UpgradeCasesMod.id("loot_case"),
            new ExtendedScreenHandlerType<LootCaseScreenHandler, Integer>(
                    (syncId, playerInventory, typeId) ->
                            new LootCaseScreenHandler(syncId, playerInventory, LootCaseType.byId(typeId)),
                    PacketCodecs.VAR_INT));

    private ModScreenHandlers() {}

    public static void register() {
        // Вызов гарантирует загрузку класса и регистрацию.
    }
}
