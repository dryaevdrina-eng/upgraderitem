package com.example.upgradecases.item;

/**
 * Типы лутовых кейсов. В отличие от кейсов улучшения, они просто выдают награду.
 * jackpotChance — шанс (0.0–1.0) выбить незеритовый предмет с топ-зачарованиями.
 */
public enum LootCaseType {
    ARMOR("case_armor", 0.001),   // 0.1%
    PICKAXE("case_pickaxe", 0.003), // 0.3%
    SWORD("case_sword", 0.005);   // 0.5%

    private final String itemName;
    private final double jackpotChance;

    LootCaseType(String itemName, double jackpotChance) {
        this.itemName = itemName;
        this.jackpotChance = jackpotChance;
    }

    public String getItemName() { return itemName; }
    public double getJackpotChance() { return jackpotChance; }

    public static LootCaseType byId(int id) {
        LootCaseType[] values = values();
        return values[Math.floorMod(id, values.length)];
    }
}
