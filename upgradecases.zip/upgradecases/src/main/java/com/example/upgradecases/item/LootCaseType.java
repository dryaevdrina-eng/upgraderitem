package com.example.upgradecases.item;

/**
 * Типы лутовых кейсов. В отличие от кейсов улучшения, они просто выдают награду.
 * jackpotChance — шанс (0.0–1.0) выбить джекпот (см. CasePrizes).
 * Новый кейс: добавь строку сюда, таблицу призов в CasePrizes, модель/текстуру/перевод.
 */
public enum LootCaseType {
    ARMOR("case_armor", 0.001),
    PICKAXE("case_pickaxe", 0.003),
    SWORD("case_sword", 0.005),
    JEWEL("case_jewel", 0.003),
    AXE("case_axe", 0.004),
    FIRE("case_fire", 0.005),
    NETHER("case_nether", 0.003),
    OCEAN("case_ocean", 0.005),
    END("case_end", 0.003),
    FOREST("case_forest", 0.005),
    MINER("case_miner", 0.004),
    ARCHER("case_archer", 0.004),
    FARM("case_farm", 0.005),
    ICE("case_ice", 0.004);

    private final String itemName;
    private final double jackpotChance;

    LootCaseType(String itemName, double jackpotChance) {
        this.itemName = itemName;
        this.jackpotChance = jackpotChance;
    }

    public String getItemName() { return itemName; }
    public double getJackpotChance() { return jackpotChance; }

    public static LootCaseType byId(int id) {
        LootCaseType[] values = values();
        return values[Math.floorMod(id, values.length)];
    }
}
