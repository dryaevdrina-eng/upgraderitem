package com.example.upgradecases.client;

import com.example.upgradecases.screen.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

/** Клиентская инициализация: привязываем Screen к типам ScreenHandler. */
public class UpgradeCasesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(ModScreenHandlers.CASE, CaseScreen::new);
        HandledScreens.register(ModScreenHandlers.LOOT_CASE, LootCaseScreen::new);
    }
}
