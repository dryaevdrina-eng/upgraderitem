package com.example.upgradecases;

import com.example.upgradecases.item.ModItems;
import com.example.upgradecases.screen.ModScreenHandlers;
import com.example.upgradecases.world.VillageHouses;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Главный класс мода (общий для клиента и сервера).
 * Порядок важен: сначала предметы, затем типы ScreenHandler.
 */
public class UpgradeCasesMod implements ModInitializer {
    public static final String MOD_ID = "upgradecases";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Удобный хелпер для создания Identifier в нашем пространстве имён. */
    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.register();
        ModScreenHandlers.register();
        VillageHouses.register();
        LOGGER.info("Upgrade Cases загружен!");
    }
}
