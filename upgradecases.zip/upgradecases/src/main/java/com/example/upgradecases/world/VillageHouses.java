package com.example.upgradecases.world;

import com.example.upgradecases.UpgradeCasesMod;
import com.example.upgradecases.mixin.StructurePoolAccessor;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.structure.pool.StructurePool;
import net.minecraft.structure.pool.StructurePoolElement;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Добавляет домик с сундуком и жителем (структура upgradecases:village/case_house)
 * в списки домов всех типов ванильных деревень, не более одного на деревню.
 * Работает только в НОВЫХ чанках: уже созданные деревни не изменятся.
 */
public final class VillageHouses {
    private static final String HOUSE_ID = UpgradeCasesMod.MOD_ID + ":village/case_house";
    private static final String[] VILLAGE_TYPES = {"plains", "desert", "savanna", "snowy", "taiga"};

    /**
     * Вес домика в пуле (у ванильных домов обычно 1–3). Больше число = чаще деревня получает домик.
     * Больше одного на деревню всё равно не будет (см. limitToOnePerVillage).
     */
    private static final int WEIGHT = 2;

    /** Наши элементы пула (сравнение по ссылке). */
    private static final Set<StructurePoolElement> CASE_HOUSES =
            Collections.synchronizedSet(Collections.newSetFromMap(new IdentityHashMap<>()));

    /** Генераторы случайных чисел деревень, где домик уже выбран. Один Random = одна деревня. */
    private static final Set<Random> USED_IN_VILLAGE =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));

    private VillageHouses() {}

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTING.register(VillageHouses::addHouse);
    }

    /**
     * Вызывается из StructurePoolMixin с перемешанным списком кандидатов.
     * Если домик уже был выбран в этой деревне — убираем его из списка;
     * иначе оставляем одну копию в начале списка и запоминаем деревню.
     */
    public static void limitToOnePerVillage(Random random, List<StructurePoolElement> list) {
        if (list == null || CASE_HOUSES.isEmpty()) return;

        StructurePoolElement ours = null;
        for (StructurePoolElement element : list) {
            if (CASE_HOUSES.contains(element)) {
                ours = element;
                break;
            }
        }
        if (ours == null) return;

        try {
            list.removeIf(CASE_HOUSES::contains);
            if (USED_IN_VILLAGE.add(random)) {
                list.add(0, ours); // первая попытка в этой деревне
            }
        } catch (UnsupportedOperationException ignored) {
            // список неизменяемый — лимит не применить, ничего страшного
        }
    }

    private static void addHouse(MinecraftServer server) {
        try {
            Registry<StructurePool> pools = server.getRegistryManager().get(RegistryKeys.TEMPLATE_POOL);

            for (String type : VILLAGE_TYPES) {
                StructurePool pool = pools.get(Identifier.ofVanilla("village/" + type + "/houses"));
                if (pool == null) continue;

                StructurePoolElement element = StructurePoolElement.ofSingle(HOUSE_ID)
                        .apply(StructurePool.Projection.RIGID);
                CASE_HOUSES.add(element);

                StructurePoolAccessor accessor = (StructurePoolAccessor) pool;

                // 1) список для случайного выбора: элемент добавляется WEIGHT раз
                for (int i = 0; i < WEIGHT; i++) {
                    accessor.upgradecases$getElements().add(element);
                }
                // 2) список «элемент + вес»
                List<Pair<StructurePoolElement, Integer>> counts = new ArrayList<>(accessor.upgradecases$getElementCounts());
                counts.add(Pair.of(element, WEIGHT));
                accessor.upgradecases$setElementCounts(counts);
            }
            UpgradeCasesMod.LOGGER.info("Домик с кейсами добавлен в деревни");
        } catch (Exception e) {
            UpgradeCasesMod.LOGGER.error("Не удалось добавить домик в деревни", e);
        }
    }
}
