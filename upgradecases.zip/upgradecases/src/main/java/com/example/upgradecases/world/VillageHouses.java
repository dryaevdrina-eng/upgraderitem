package com.example.upgradecases.world;

import com.example.upgradecases.UpgradeCasesMod;
import com.example.upgradecases.mixin.StructurePoolAccessor;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.structure.pool.StructurePool;
import net.minecraft.structure.pool.StructurePoolElement;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Добавляет домик с сундуком (структура upgradecases:village/case_house)
 * в списки домов всех типов ванильных деревень.
 * Работает только в НОВЫХ чанках: уже созданные деревни не изменятся.
 */
public final class VillageHouses {
    private static final String HOUSE_ID = UpgradeCasesMod.MOD_ID + ":village/case_house";
    private static final String[] VILLAGE_TYPES = {"plains", "desert", "savanna", "snowy", "taiga"};

    /** Вес домика в пуле (у ванильных домов обычно 1–3). Больше число = чаще встречается. */
    private static final int WEIGHT = 5;

    private VillageHouses() {}

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTING.register(VillageHouses::addHouse);
    }

    private static void addHouse(MinecraftServer server) {
        try {
            Registry<StructurePool> pools = server.getRegistryManager().get(RegistryKeys.TEMPLATE_POOL);

            for (String type : VILLAGE_TYPES) {
                StructurePool pool = pools.get(Identifier.ofVanilla("village/" + type + "/houses"));
                if (pool == null) continue;

                StructurePoolElement element = StructurePoolElement.ofSingle(HOUSE_ID)
                        .apply(StructurePool.Projection.RIGID);

                StructurePoolAccessor accessor = (StructurePoolAccessor) pool;

                // 1) список для случайного выбора: элемент добавляется WEIGHT раз
                for (int i = 0; i < WEIGHT; i++) {
                    accessor.upgradecases$getElements().add(element);
                }
                // 2) список «элемент + вес»
                List<Pair<StructurePoolElement, Integer>> counts = new ArrayList<>(accessor.upgradecases$getElementCounts());
                counts.add(Pair.of(element, WEIGHT));
                accessor.upgradecases$setElementCounts(counts);
            }
            UpgradeCasesMod.LOGGER.info("Домик с кейсами добавлен в деревни");
        } catch (Exception e) {
            // Ошибка тут не должна ронять игру: просто не будет домика.
            UpgradeCasesMod.LOGGER.error("Не удалось добавить домик в деревни", e);
        }
    }
}
