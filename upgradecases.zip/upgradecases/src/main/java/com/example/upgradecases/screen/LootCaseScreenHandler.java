package com.example.upgradecases.screen;

import com.example.upgradecases.item.LootCaseType;
import com.example.upgradecases.item.ModItems;
import com.example.upgradecases.loot.CasePrize;
import com.example.upgradecases.loot.CasePrizes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Vector3f;

import java.util.List;

/**
 * Контейнер лутового кейса.
 * Сервер выбирает приз сразу при нажатии «Открыть» и синхронизирует его индекс.
 * Клиент крутит рулетку и останавливается на этом призе, затем шлёт BTN_FINISH,
 * после чего сервер выдаёт награду. При закрытии окна награда выдаётся автоматически.
 */
public class LootCaseScreenHandler extends ScreenHandler {
    public static final int RESULT_SLOT = 0;

    public static final int BTN_OPEN = 0;
    public static final int BTN_FINISH = 1;

    private static final int PROP_PRIZE = 0; // 0 = нет, иначе индекс приза + 1
    private static final int PROP_STATE = 1;

    public static final int STATE_IDLE = 0;
    public static final int STATE_ROLLING = 1;

    public static final int ANIMATION_MS = 4000;
    private static final int MIN_SERVER_TICKS = 65; // 4000 мс = 80 тиков, с запасом на лаги

    private final LootCaseType type;
    private final Inventory resultInventory = new SimpleInventory(1);
    private final PropertyDelegate properties = new ArrayPropertyDelegate(2);

    private int pendingPrize;
    private long rollStartTick;

    public LootCaseScreenHandler(int syncId, PlayerInventory playerInventory, LootCaseType type) {
        super(ModScreenHandlers.LOOT_CASE, syncId);
        this.type = type;

        this.addSlot(new Slot(resultInventory, RESULT_SLOT, 130, 58) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return false;
            }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 102 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 160));
        }

        this.addProperties(properties);
    }

    public LootCaseType getCaseType() { return type; }
    public int getState() { return properties.get(PROP_STATE); }
    /** Индекс выпавшего приза или -1, если ещё нет. */
    public int getPrizeIndex() { return properties.get(PROP_PRIZE) - 1; }
    public boolean isIdle() { return getState() == STATE_IDLE; }

    @Override
    public boolean onButtonClick(PlayerEntity player, int id) {
        if (!(player instanceof ServerPlayerEntity serverPlayer)) return false;
        return switch (id) {
            case BTN_OPEN -> startOpen(serverPlayer);
            case BTN_FINISH -> {
                boolean enoughTime = getState() == STATE_ROLLING
                        && serverPlayer.getWorld().getTime() - rollStartTick >= MIN_SERVER_TICKS;
                if (enoughTime) finishOpen(serverPlayer);
                yield enoughTime;
            }
            default -> false;
        };
    }

    private boolean startOpen(ServerPlayerEntity player) {
        if (!isIdle()) return false;
        if (!resultInventory.getStack(RESULT_SLOT).isEmpty()) {
            player.sendMessage(Text.translatable("msg.upgradecases.take_result"), true);
            return false;
        }
        if (!consumeCase(player)) {
            player.sendMessage(Text.translatable("msg.upgradecases.no_case"), true);
            return false;
        }

        pendingPrize = CasePrizes.roll(type, player.getRandom());
        rollStartTick = player.getWorld().getTime();

        properties.set(PROP_PRIZE, pendingPrize + 1);
        properties.set(PROP_STATE, STATE_ROLLING);

        player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLOCK_CHEST_OPEN, SoundCategory.PLAYERS, 0.8f, 1.2f);
        return true;
    }

    private boolean consumeCase(ServerPlayerEntity player) {
        Item caseItem = ModItems.forLootType(type);
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(caseItem)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }

    private void finishOpen(ServerPlayerEntity player) {
        if (getState() != STATE_ROLLING) return;

        ServerWorld world = player.getServerWorld();
        List<CasePrize> prizes = CasePrizes.of(type);
        CasePrize prize = prizes.get(pendingPrize);
        ItemStack reward = prize.createRewardStack(world.getRegistryManager());
        resultInventory.setStack(RESULT_SLOT, reward);

        if (prize.jackpot()) {
            // ДЖЕКПОТ: много фиолетовых частиц, звуки и сообщение всему серверу.
            world.spawnParticles(new DustParticleEffect(new Vector3f(0.627f, 0.125f, 0.941f), 1.8f),
                    player.getX(), player.getBodyY(0.5), player.getZ(), 120, 0.8, 1.0, 0.8, 0.03);
            world.spawnParticles(ParticleTypes.WITCH,
                    player.getX(), player.getBodyY(0.5), player.getZ(), 60, 0.8, 1.0, 0.8, 0.08);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 0.7f);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.5f, 1.0f);
            if (player.getServer() != null) {
                player.getServer().getPlayerManager().broadcast(
                        Text.translatable("msg.upgradecases.jackpot_broadcast",
                                player.getDisplayName(), reward.toHoverableText())
                                .formatted(Formatting.LIGHT_PURPLE), false);
            }
        } else {
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.8f, 1.0f);
        }

        properties.set(PROP_PRIZE, 0);
        properties.set(PROP_STATE, STATE_IDLE);
        this.sendContentUpdates();
    }

    @Override
    public void onClosed(PlayerEntity player) {
        super.onClosed(player);
        if (player instanceof ServerPlayerEntity serverPlayer) {
            if (getState() == STATE_ROLLING) finishOpen(serverPlayer);
            this.dropInventory(player, resultInventory);
        }
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slotIndex) {
        Slot slot = this.slots.get(slotIndex);
        if (slotIndex != RESULT_SLOT || !slot.hasStack()) return ItemStack.EMPTY;

        ItemStack original = slot.getStack();
        ItemStack copy = original.copy();
        if (!this.insertItem(original, 1, this.slots.size(), true)) return ItemStack.EMPTY;

        if (original.isEmpty()) slot.setStack(ItemStack.EMPTY);
        else slot.markDirty();
        return copy;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }
}
