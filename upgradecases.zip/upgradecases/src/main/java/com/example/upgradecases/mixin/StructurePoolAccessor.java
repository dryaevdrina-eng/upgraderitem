package com.example.upgradecases.mixin;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.structure.pool.StructurePool;
import net.minecraft.structure.pool.StructurePoolElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

/** Доступ к спискам элементов пула шаблонов, чтобы добавить в деревни наш домик. */
@Mixin(StructurePool.class)
public interface StructurePoolAccessor {
    @Accessor("elements")
    ObjectArrayList<StructurePoolElement> upgradecases$getElements();

    @Accessor("elementCounts")
    List<Pair<StructurePoolElement, Integer>> upgradecases$getElementCounts();

    @Mutable
    @Accessor("elementCounts")
    void upgradecases$setElementCounts(List<Pair<StructurePoolElement, Integer>> elementCounts);
}
