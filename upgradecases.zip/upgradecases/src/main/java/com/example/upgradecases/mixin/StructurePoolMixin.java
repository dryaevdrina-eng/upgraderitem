package com.example.upgradecases.mixin;

import com.example.upgradecases.world.VillageHouses;
import net.minecraft.structure.pool.StructurePool;
import net.minecraft.structure.pool.StructurePoolElement;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Генератор деревни при каждом соединении вызывает этот метод, получая перемешанный список кандидатов.
 * Здесь мы следим, чтобы наш домик попал в одну деревню не больше одного раза.
 * require = 0: если метод в будущих версиях переименуют, мод не упадёт (просто лимита не будет).
 */
@Mixin(StructurePool.class)
public abstract class StructurePoolMixin {
    @Inject(method = "getElementIndicesInRandomOrder", at = @At("RETURN"), require = 0)
    private void upgradecases$onePerVillage(Random random, CallbackInfoReturnable<List<StructurePoolElement>> cir) {
        VillageHouses.limitToOnePerVillage(random, cir.getReturnValue());
    }
}
