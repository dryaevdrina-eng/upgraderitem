package com.example.upgradecases.util;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Хранит игроков, которым командой /jackpot включён гарантированный джекпот.
 * Флаг срабатывает один раз: на следующем открытии/улучшении кейса.
 * Хранится в памяти: после перезапуска сервера сбрасывается.
 */
public final class JackpotManager {
    private static final Set<UUID> ARMED = ConcurrentHashMap.newKeySet();

    private JackpotManager() {}

    public static void arm(ServerPlayerEntity player) {
        ARMED.add(player.getUuid());
    }

    /** Возвращает true и сбрасывает флаг, если джекпот был включён. */
    public static boolean consume(ServerPlayerEntity player) {
        return ARMED.remove(player.getUuid());
    }
}
