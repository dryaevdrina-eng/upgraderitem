package com.example.upgradecases.loot;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Один приз кейса. Список призов одинаков на клиенте и сервере,
 * поэтому сервер передаёт клиенту только индекс выпавшего приза.
 */
public record CasePrize(Item item, int weight, boolean jackpot, List<EnchantSpec> enchants, int count) {

    /** Зачарование по id из ванильного пространства имён ("sharpness") и уровень. */
    public record EnchantSpec(String id, int level) {}

    public static CasePrize normal(Item item, int weight) {
        return new CasePrize(item, weight, false, List.of(), 1);
    }

    public static CasePrize normal(Item item, int weight, int count) {
        return new CasePrize(item, weight, false, List.of(), count);
    }

    public static CasePrize jackpot(Item item, EnchantSpec... enchants) {
        return new CasePrize(item, 0, true, List.of(enchants), 1);
    }

    /** Джекпот-стопка предметов без зачарований (например, 3 незеритовых слитка). */
    public static CasePrize jackpot(Item item, int count) {
        return new CasePrize(item, 0, true, List.of(), count);
    }

    public static EnchantSpec ench(String id, int level) {
        return new EnchantSpec(id, level);
    }

    /** Стек для отображения в рулетке (клиент): у джекпота просто блеск. */
    public ItemStack createDisplayStack() {
        ItemStack stack = new ItemStack(item, count);
        if (jackpot) stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        return stack;
    }

    /** Реальная награда (сервер) с настоящими зачарованиями. */
    public ItemStack createRewardStack(DynamicRegistryManager registries) {
        ItemStack stack = new ItemStack(item, count);
        Registry<Enchantment> registry = registries.get(RegistryKeys.ENCHANTMENT);
        for (EnchantSpec spec : enchants) {
            RegistryKey<Enchantment> key = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.ofVanilla(spec.id()));
            registry.getEntry(key).ifPresent(entry -> stack.addEnchantment(entry, spec.level()));
        }
        return stack;
    }
}
