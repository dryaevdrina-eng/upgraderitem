package com.example.upgradecases.world;

import com.example.upgradecases.item.LootCaseType;
import com.example.upgradecases.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Добавляет кейсы в сундуки ванильных структур.
 * Каждая запись «предмет + шанс» — отдельный бросок: шанс это вероятность, что кейс окажется в сундуке.
 * Пути таблиц — это id ванильных таблиц добычи без "minecraft:" (например "chests/shipwreck_treasure").
 * Лут считается в момент открытия сундука, поэтому работает и в уже созданных, но не открытых сундуках.
 */
public final class ModLoot {
    private record Drop(Item item, float chance) {}

    private static final Map<String, List<Drop>> DROPS = new HashMap<>();

    private ModLoot() {}

    private static void add(Item item, float chance, String... tablePaths) {
        for (String path : tablePaths) {
            DROPS.computeIfAbsent(path, p -> new ArrayList<>()).add(new Drop(item, chance));
        }
    }

    private static Item loot(LootCaseType type) {
        return ModItems.forLootType(type);
    }

    public static void register() {
        // ---------- кейсы улучшения ----------
        add(ModItems.CASE_COMMON, 0.25f, "chests/simple_dungeon");
        add(ModItems.CASE_COMMON, 0.20f, "chests/abandoned_mineshaft", "chests/village/village_toolsmith",
                "chests/village/village_weaponsmith", "chests/village/village_armorer");
        add(ModItems.CASE_COMMON, 0.15f, "chests/desert_pyramid", "chests/shipwreck_supply");

        add(ModItems.CASE_RARE, 0.20f, "chests/jungle_temple", "chests/woodland_mansion", "chests/buried_treasure");
        add(ModItems.CASE_RARE, 0.15f, "chests/desert_pyramid", "chests/shipwreck_treasure");
        add(ModItems.CASE_RARE, 0.10f, "chests/bastion_other", "chests/nether_bridge", "chests/pillager_outpost");

        add(ModItems.CASE_LEGENDARY, 0.15f, "chests/ancient_city", "chests/end_city_treasure", "chests/bastion_treasure");
        add(ModItems.CASE_LEGENDARY, 0.10f, "chests/stronghold_library");
        add(ModItems.CASE_LEGENDARY, 0.05f, "chests/woodland_mansion");

        // ---------- морской: затонувшие корабли, подводные руины, клады ----------
        add(loot(LootCaseType.OCEAN), 0.30f, "chests/shipwreck_treasure", "chests/underwater_ruin_big");
        add(loot(LootCaseType.OCEAN), 0.25f, "chests/buried_treasure");
        add(loot(LootCaseType.OCEAN), 0.15f, "chests/shipwreck_supply", "chests/shipwreck_map", "chests/underwater_ruin_small");

        // ---------- огненный и адский: Незер ----------
        add(loot(LootCaseType.FIRE), 0.20f, "chests/nether_bridge");
        add(loot(LootCaseType.FIRE), 0.15f, "chests/ruined_portal");
        add(loot(LootCaseType.FIRE), 0.10f, "chests/bastion_other");

        add(loot(LootCaseType.NETHER), 0.30f, "chests/bastion_treasure");
        add(loot(LootCaseType.NETHER), 0.15f, "chests/bastion_bridge", "chests/bastion_hoglin_stable");
        add(loot(LootCaseType.NETHER), 0.10f, "chests/bastion_other", "chests/nether_bridge", "chests/ruined_portal");

        // ---------- Край ----------
        add(loot(LootCaseType.END), 0.30f, "chests/end_city_treasure");
        add(loot(LootCaseType.END), 0.20f, "chests/stronghold_library");
        add(loot(LootCaseType.END), 0.10f, "chests/stronghold_corridor", "chests/stronghold_crossing");

        // ---------- лесной ----------
        add(loot(LootCaseType.FOREST), 0.25f, "chests/woodland_mansion");
        add(loot(LootCaseType.FOREST), 0.20f, "chests/jungle_temple");
        add(loot(LootCaseType.FOREST), 0.08f, "chests/village/village_taiga_house", "chests/village/village_plains_house");

        // ---------- шахтёрский, кирки ----------
        add(loot(LootCaseType.MINER), 0.20f, "chests/abandoned_mineshaft");
        add(loot(LootCaseType.MINER), 0.15f, "chests/simple_dungeon");
        add(loot(LootCaseType.MINER), 0.10f, "chests/village/village_toolsmith");
        add(loot(LootCaseType.PICKAXE), 0.12f, "chests/abandoned_mineshaft", "chests/village/village_toolsmith");
        add(loot(LootCaseType.PICKAXE), 0.08f, "chests/simple_dungeon");

        // ---------- лучника ----------
        add(loot(LootCaseType.ARCHER), 0.25f, "chests/pillager_outpost");
        add(loot(LootCaseType.ARCHER), 0.20f, "chests/village/village_fletcher");
        add(loot(LootCaseType.ARCHER), 0.10f, "chests/woodland_mansion");

        // ---------- фермерский ----------
        add(loot(LootCaseType.FARM), 0.15f, "chests/village/village_butcher");
        add(loot(LootCaseType.FARM), 0.10f, "chests/village/village_plains_house", "chests/village/village_savanna_house",
                "chests/village/village_shepherd");

        // ---------- ледяной ----------
        add(loot(LootCaseType.ICE), 0.30f, "chests/igloo_chest");
        add(loot(LootCaseType.ICE), 0.15f, "chests/village/village_snowy_house");

        // ---------- топоры, мечи, броня ----------
        add(loot(LootCaseType.AXE), 0.12f, "chests/village/village_toolsmith", "chests/village/village_weaponsmith");
        add(loot(LootCaseType.AXE), 0.10f, "chests/pillager_outpost", "chests/woodland_mansion");

        add(loot(LootCaseType.SWORD), 0.20f, "chests/village/village_weaponsmith");
        add(loot(LootCaseType.SWORD), 0.10f, "chests/woodland_mansion");
        add(loot(LootCaseType.SWORD), 0.08f, "chests/simple_dungeon", "chests/bastion_treasure");

        add(loot(LootCaseType.ARMOR), 0.20f, "chests/village/village_armorer");
        add(loot(LootCaseType.ARMOR), 0.10f, "chests/bastion_other");
        add(loot(LootCaseType.ARMOR), 0.08f, "chests/woodland_mansion");

        // ---------- драгоценности ----------
        add(loot(LootCaseType.JEWEL), 0.20f, "chests/desert_pyramid");
        add(loot(LootCaseType.JEWEL), 0.15f, "chests/jungle_temple", "chests/buried_treasure");
        add(loot(LootCaseType.JEWEL), 0.08f, "chests/simple_dungeon");

        // Подписываемся на загрузку таблиц добычи и добавляем отдельный пул на каждую запись.
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            // Трогаем только встроенные ванильные таблицы (не датапаки и не наш домик).
            if (!source.isBuiltin() || !"minecraft".equals(key.getValue().getNamespace())) return;

            List<Drop> drops = DROPS.get(key.getValue().getPath());
            if (drops == null) return;

            for (Drop drop : drops) {
                tableBuilder.pool(LootPool.builder()
                        .rolls(ConstantLootNumberProvider.create(1))
                        .conditionally(RandomChanceLootCondition.builder(drop.chance()))
                        .with(ItemEntry.builder(drop.item())));
            }
        });
    }
}
