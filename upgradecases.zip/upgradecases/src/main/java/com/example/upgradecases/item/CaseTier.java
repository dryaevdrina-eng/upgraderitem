package com.example.upgradecases.item;

/**
 * Тиры кейсов. Чем реже кейс — тем выше шанс успеха и сильнее бонус.
 */
public enum CaseTier {
    COMMON("case_common", 0.45f, 1.0),
    RARE("case_rare", 0.65f, 2.0),
    LEGENDARY("case_legendary", 0.85f, 3.0);

    private final String itemName;
    private final float successChance;
    private final double bonus;

    CaseTier(String itemName, float successChance, double bonus) {
        this.itemName = itemName;
        this.successChance = successChance;
        this.bonus = bonus;
    }

    public String getItemName() { return itemName; }

    /** Шанс успеха от 0.0 до 1.0. */
    public float getSuccessChance() { return successChance; }

    /** Прибавка к урону (оружие) или броне (броня) за один успешный апгрейд. */
    public double getBonus() { return bonus; }

    /** Безопасное получение тира по id (используется при передаче по сети). */
    public static CaseTier byId(int id) {
        CaseTier[] values = values();
        return values[Math.floorMod(id, values.length)];
    }
}
