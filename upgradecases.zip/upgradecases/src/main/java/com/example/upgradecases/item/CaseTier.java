package com.example.upgradecases.item;

/**
 * Тиры кейсов улучшения. Чем реже кейс — тем выше шанс успеха, сильнее бонус
 * и больше уровней зачарований добавляется предмету.
 */
public enum CaseTier {
    COMMON("case_common", 0.45f, 1.0, 1),
    RARE("case_rare", 0.65f, 2.0, 2),
    LEGENDARY("case_legendary", 0.85f, 3.0, 3);

    private final String itemName;
    private final float successChance;
    private final double bonus;
    private final int enchantRolls;

    CaseTier(String itemName, float successChance, double bonus, int enchantRolls) {
        this.itemName = itemName;
        this.successChance = successChance;
        this.bonus = bonus;
        this.enchantRolls = enchantRolls;
    }

    public String getItemName() { return itemName; }

    /** Шанс успеха от 0.0 до 1.0. */
    public float getSuccessChance() { return successChance; }

    /** Прибавка к урону (оружие) или броне (броня) за один успешный апгрейд. */
    public double getBonus() { return bonus; }

    /** Сколько раз за апгрейд повышается уровень случайного зачарования. */
    public int getEnchantRolls() { return enchantRolls; }

    /** Безопасное получение тира по id (используется при передаче по сети). */
    public static CaseTier byId(int id) {
        CaseTier[] values = values();
        return values[Math.floorMod(id, values.length)];
    }
}
