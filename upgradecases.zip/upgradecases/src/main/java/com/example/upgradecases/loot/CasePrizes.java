package com.example.upgradecases.loot;

import com.example.upgradecases.item.LootCaseType;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import static com.example.upgradecases.loot.CasePrize.ench;

/**
 * Таблицы призов. Сначала идут обычные призы, потом джекпоты.
 * Чтобы поменять шансы/призы — правь этот файл и LootCaseType.
 */
public final class CasePrizes {
    private static final Map<LootCaseType, List<CasePrize>> CACHE = new EnumMap<>(LootCaseType.class);

    private CasePrizes() {}

    public static List<CasePrize> of(LootCaseType type) {
        return CACHE.computeIfAbsent(type, CasePrizes::build);
    }

    /** Выбор приза на сервере. Возвращает индекс в списке of(type). */
    public static int roll(LootCaseType type, Random random) {
        List<CasePrize> prizes = of(type);

        if (random.nextDouble() < type.getJackpotChance()) {
            List<Integer> jackpots = new ArrayList<>();
            for (int i = 0; i < prizes.size(); i++) if (prizes.get(i).jackpot()) jackpots.add(i);
            return jackpots.get(random.nextInt(jackpots.size()));
        }

        int total = 0;
        for (CasePrize p : prizes) if (!p.jackpot()) total += p.weight();
        int roll = random.nextInt(total);
        for (int i = 0; i < prizes.size(); i++) {
            CasePrize p = prizes.get(i);
            if (p.jackpot()) continue;
            roll -= p.weight();
            if (roll < 0) return i;
        }
        return 0;
    }

    /** Выбор случайного джекпот-приза (для команды /jackpot). */
    public static int rollJackpot(LootCaseType type, Random random) {
        List<CasePrize> prizes = of(type);
        List<Integer> jackpots = new ArrayList<>();
        for (int i = 0; i < prizes.size(); i++) if (prizes.get(i).jackpot()) jackpots.add(i);
        return jackpots.get(random.nextInt(jackpots.size()));
    }

    private static List<CasePrize> build(LootCaseType type) {
        List<CasePrize> list = new ArrayList<>();
        switch (type) {
            case ARMOR -> {
                addSet(list, 10, Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS);
                addSet(list, 5, Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS);
                addSet(list, 6, Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);
                addSet(list, 3, Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS);
                addSet(list, 1, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

                // Джекпот: незеритовая броня с максимальными ванильными чарами.
                list.add(CasePrize.jackpot(Items.NETHERITE_HELMET,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("respiration", 3), ench("aqua_affinity", 1), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_CHESTPLATE,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_LEGGINGS,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("swift_sneak", 3), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_BOOTS,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("feather_falling", 4), ench("depth_strider", 3), ench("thorns", 3)));
            }
            case JEWEL -> {
                // Драгоценности: руды и слитки, а с шансом 0.3% (см. LootCaseType) незеритовый слиток.
                list.add(CasePrize.normal(Items.IRON_INGOT, 30, 4));
                list.add(CasePrize.normal(Items.COPPER_INGOT, 20, 6));
                list.add(CasePrize.normal(Items.GOLD_INGOT, 18, 3));
                list.add(CasePrize.normal(Items.LAPIS_LAZULI, 10, 6));
                list.add(CasePrize.normal(Items.REDSTONE, 10, 6));
                list.add(CasePrize.normal(Items.EMERALD, 8, 2));
                list.add(CasePrize.normal(Items.DIAMOND, 6, 1));
                list.add(CasePrize.normal(Items.DIAMOND, 2, 3));
                list.add(CasePrize.normal(Items.NETHERITE_SCRAP, 1, 1));
                list.add(CasePrize.jackpot(Items.NETHERITE_INGOT));
            }
            case AXE -> {
                addTools(list, Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE,
                        Items.GOLDEN_AXE, Items.DIAMOND_AXE);
                list.add(CasePrize.jackpot(Items.NETHERITE_AXE,
                        ench("sharpness", 5), ench("efficiency", 5), ench("unbreaking", 3), ench("mending", 1)));
            }
            case FIRE -> {
                list.add(CasePrize.normal(Items.FIRE_CHARGE, 25, 6));
                list.add(CasePrize.normal(Items.COAL, 22, 16));
                list.add(CasePrize.normal(Items.CHARCOAL, 15, 16));
                list.add(CasePrize.normal(Items.BLAZE_POWDER, 15, 4));
                list.add(CasePrize.normal(Items.MAGMA_CREAM, 8, 3));
                list.add(CasePrize.normal(Items.BLAZE_ROD, 8, 3));
                list.add(CasePrize.normal(Items.FLINT_AND_STEEL, 5, 1));
                list.add(CasePrize.normal(Items.LAVA_BUCKET, 2, 1));
                list.add(CasePrize.jackpot(Items.NETHERITE_SWORD, ench("fire_aspect", 2), ench("sharpness", 5), ench("looting", 3), ench("unbreaking", 3), ench("mending", 1)));
                list.add(CasePrize.jackpot(Items.NETHERITE_CHESTPLATE, ench("fire_protection", 4), ench("unbreaking", 3), ench("mending", 1), ench("thorns", 3)));
            }
            case NETHER -> {
                list.add(CasePrize.normal(Items.NETHERRACK, 20, 32));
                list.add(CasePrize.normal(Items.SOUL_SAND, 12, 16));
                list.add(CasePrize.normal(Items.NETHER_WART, 14, 8));
                list.add(CasePrize.normal(Items.QUARTZ, 14, 8));
                list.add(CasePrize.normal(Items.GLOWSTONE_DUST, 12, 8));
                list.add(CasePrize.normal(Items.GOLD_INGOT, 8, 4));
                list.add(CasePrize.normal(Items.MAGMA_BLOCK, 6, 8));
                list.add(CasePrize.normal(Items.GHAST_TEAR, 5, 1));
                list.add(CasePrize.normal(Items.ANCIENT_DEBRIS, 6, 1));
                list.add(CasePrize.normal(Items.NETHERITE_SCRAP, 3, 2));
                list.add(CasePrize.jackpot(Items.NETHERITE_INGOT, 3));
            }
            case OCEAN -> {
                list.add(CasePrize.normal(Items.KELP, 18, 16));
                list.add(CasePrize.normal(Items.COD, 12, 4));
                list.add(CasePrize.normal(Items.SALMON, 12, 4));
                list.add(CasePrize.normal(Items.PRISMARINE_SHARD, 14, 8));
                list.add(CasePrize.normal(Items.PRISMARINE_CRYSTALS, 10, 6));
                list.add(CasePrize.normal(Items.INK_SAC, 8, 6));
                list.add(CasePrize.normal(Items.SPONGE, 8, 2));
                list.add(CasePrize.normal(Items.NAUTILUS_SHELL, 8, 2));
                list.add(CasePrize.normal(Items.SEA_PICKLE, 6, 4));
                list.add(CasePrize.normal(Items.HEART_OF_THE_SEA, 4, 1));
                list.add(CasePrize.jackpot(Items.TRIDENT, ench("impaling", 5), ench("loyalty", 3), ench("channeling", 1), ench("unbreaking", 3), ench("mending", 1)));
                list.add(CasePrize.jackpot(Items.TURTLE_HELMET, ench("respiration", 3), ench("aqua_affinity", 1), ench("protection", 4), ench("unbreaking", 3), ench("mending", 1), ench("thorns", 3)));
            }
            case END -> {
                list.add(CasePrize.normal(Items.ENDER_PEARL, 22, 3));
                list.add(CasePrize.normal(Items.END_STONE, 14, 16));
                list.add(CasePrize.normal(Items.CHORUS_FRUIT, 14, 8));
                list.add(CasePrize.normal(Items.POPPED_CHORUS_FRUIT, 10, 8));
                list.add(CasePrize.normal(Items.PURPUR_BLOCK, 10, 16));
                list.add(CasePrize.normal(Items.ENDER_EYE, 8, 3));
                list.add(CasePrize.normal(Items.END_ROD, 8, 6));
                list.add(CasePrize.normal(Items.OBSIDIAN, 6, 4));
                list.add(CasePrize.normal(Items.SHULKER_SHELL, 4, 2));
                list.add(CasePrize.normal(Items.DRAGON_BREATH, 4, 1));
                list.add(CasePrize.jackpot(Items.ELYTRA, ench("unbreaking", 3), ench("mending", 1)));
                list.add(CasePrize.jackpot(Items.SHULKER_BOX));
            }
            case FOREST -> {
                list.add(CasePrize.normal(Items.OAK_LOG, 14, 16));
                list.add(CasePrize.normal(Items.SPRUCE_LOG, 12, 16));
                list.add(CasePrize.normal(Items.BIRCH_LOG, 10, 16));
                list.add(CasePrize.normal(Items.DARK_OAK_LOG, 8, 16));
                list.add(CasePrize.normal(Items.APPLE, 14, 6));
                list.add(CasePrize.normal(Items.HONEY_BOTTLE, 8, 2));
                list.add(CasePrize.normal(Items.SWEET_BERRIES, 10, 8));
                list.add(CasePrize.normal(Items.MOSS_BLOCK, 8, 8));
                list.add(CasePrize.normal(Items.BONE_MEAL, 8, 8));
                list.add(CasePrize.normal(Items.GOLDEN_APPLE, 6, 1));
                list.add(CasePrize.normal(Items.RED_MUSHROOM, 2, 4));
                list.add(CasePrize.jackpot(Items.ENCHANTED_GOLDEN_APPLE));
                list.add(CasePrize.jackpot(Items.TOTEM_OF_UNDYING));
            }
            case MINER -> {
                list.add(CasePrize.normal(Items.COBBLESTONE, 16, 32));
                list.add(CasePrize.normal(Items.COAL, 16, 16));
                list.add(CasePrize.normal(Items.RAW_IRON, 14, 8));
                list.add(CasePrize.normal(Items.RAW_COPPER, 10, 8));
                list.add(CasePrize.normal(Items.RAW_GOLD, 8, 6));
                list.add(CasePrize.normal(Items.REDSTONE, 10, 12));
                list.add(CasePrize.normal(Items.LAPIS_LAZULI, 8, 10));
                list.add(CasePrize.normal(Items.FLINT, 4, 4));
                list.add(CasePrize.normal(Items.TNT, 4, 4));
                list.add(CasePrize.normal(Items.DIAMOND, 4, 1));
                list.add(CasePrize.normal(Items.EMERALD, 3, 2));
                list.add(CasePrize.normal(Items.AMETHYST_SHARD, 3, 6));
                list.add(CasePrize.jackpot(Items.NETHERITE_SHOVEL, ench("efficiency", 5), ench("unbreaking", 3), ench("fortune", 3), ench("mending", 1)));
                list.add(CasePrize.jackpot(Items.DIAMOND_BLOCK, 3));
            }
            case ARCHER -> {
                list.add(CasePrize.normal(Items.ARROW, 24, 16));
                list.add(CasePrize.normal(Items.FEATHER, 14, 8));
                list.add(CasePrize.normal(Items.STRING, 12, 8));
                list.add(CasePrize.normal(Items.FLINT, 10, 8));
                list.add(CasePrize.normal(Items.SPECTRAL_ARROW, 10, 8));
                list.add(CasePrize.normal(Items.BOW, 10, 1));
                list.add(CasePrize.normal(Items.CROSSBOW, 8, 1));
                list.add(CasePrize.normal(Items.FIREWORK_ROCKET, 6, 8));
                list.add(CasePrize.normal(Items.TARGET, 6, 1));
                list.add(CasePrize.jackpot(Items.BOW, ench("power", 5), ench("punch", 2), ench("flame", 1), ench("infinity", 1), ench("unbreaking", 3)));
                list.add(CasePrize.jackpot(Items.CROSSBOW, ench("quick_charge", 3), ench("piercing", 4), ench("unbreaking", 3), ench("mending", 1)));
            }
            case FARM -> {
                list.add(CasePrize.normal(Items.WHEAT, 14, 16));
                list.add(CasePrize.normal(Items.CARROT, 12, 12));
                list.add(CasePrize.normal(Items.POTATO, 12, 12));
                list.add(CasePrize.normal(Items.BEETROOT, 8, 8));
                list.add(CasePrize.normal(Items.BREAD, 10, 6));
                list.add(CasePrize.normal(Items.HAY_BLOCK, 6, 3));
                list.add(CasePrize.normal(Items.PUMPKIN, 6, 4));
                list.add(CasePrize.normal(Items.COOKED_BEEF, 8, 6));
                list.add(CasePrize.normal(Items.GOLDEN_CARROT, 6, 6));
                list.add(CasePrize.normal(Items.EGG, 6, 8));
                list.add(CasePrize.normal(Items.IRON_HOE, 6, 1));
                list.add(CasePrize.normal(Items.DIAMOND_HOE, 6, 1));
                list.add(CasePrize.jackpot(Items.NETHERITE_HOE, ench("efficiency", 5), ench("unbreaking", 3), ench("fortune", 3), ench("mending", 1)));
                list.add(CasePrize.jackpot(Items.DIAMOND_HORSE_ARMOR));
            }
            case ICE -> {
                list.add(CasePrize.normal(Items.SNOWBALL, 20, 16));
                list.add(CasePrize.normal(Items.SNOW_BLOCK, 14, 8));
                list.add(CasePrize.normal(Items.ICE, 14, 8));
                list.add(CasePrize.normal(Items.PACKED_ICE, 10, 6));
                list.add(CasePrize.normal(Items.BLUE_ICE, 6, 3));
                list.add(CasePrize.normal(Items.COD, 8, 4));
                list.add(CasePrize.normal(Items.SALMON, 8, 4));
                list.add(CasePrize.normal(Items.CARVED_PUMPKIN, 4, 1));
                list.add(CasePrize.normal(Items.POWDER_SNOW_BUCKET, 4, 1));
                list.add(CasePrize.normal(Items.LEATHER_BOOTS, 6, 1));
                list.add(CasePrize.normal(Items.IRON_BOOTS, 4, 1));
                list.add(CasePrize.normal(Items.DIAMOND_BOOTS, 2, 1));
                list.add(CasePrize.jackpot(Items.NETHERITE_BOOTS, ench("frost_walker", 2), ench("protection", 4), ench("feather_falling", 4), ench("unbreaking", 3), ench("mending", 1)));
            }
            case PICKAXE -> {
                addTools(list, Items.WOODEN_PICKAXE, Items.STONE_PICKAXE, Items.IRON_PICKAXE,
                        Items.GOLDEN_PICKAXE, Items.DIAMOND_PICKAXE);
                list.add(CasePrize.jackpot(Items.NETHERITE_PICKAXE,
                        ench("efficiency", 5), ench("unbreaking", 3), ench("fortune", 3), ench("mending", 1)));
            }
            case SWORD -> {
                addTools(list, Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD,
                        Items.GOLDEN_SWORD, Items.DIAMOND_SWORD);
                list.add(CasePrize.jackpot(Items.NETHERITE_SWORD,
                        ench("sharpness", 5), ench("unbreaking", 3), ench("looting", 3),
                        ench("fire_aspect", 2), ench("sweeping_edge", 3), ench("mending", 1)));
            }
        }
        return List.copyOf(list);
    }

    private static void addSet(List<CasePrize> list, int weight, Item... items) {
        for (Item item : items) list.add(CasePrize.normal(item, weight));
    }

    /** Веса: дерево, камень, железо, золото, алмаз. */
    private static void addTools(List<CasePrize> list, Item wood, Item stone, Item iron, Item gold, Item diamond) {
        list.add(CasePrize.normal(wood, 20));
        list.add(CasePrize.normal(stone, 30));
        list.add(CasePrize.normal(iron, 30));
        list.add(CasePrize.normal(gold, 12));
        list.add(CasePrize.normal(diamond, 8));
    }
}
