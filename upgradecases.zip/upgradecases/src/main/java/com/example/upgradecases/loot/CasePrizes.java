package com.example.upgradecases.loot;

import com.example.upgradecases.item.LootCaseType;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import static com.example.upgradecases.loot.CasePrize.ench;

/**
 * Таблицы призов. Сначала идут обычные призы, потом джекпоты.
 * Чтобы поменять шансы/призы — правь этот файл и LootCaseType.
 */
public final class CasePrizes {
    private static final Map<LootCaseType, List<CasePrize>> CACHE = new EnumMap<>(LootCaseType.class);

    private CasePrizes() {}

    public static List<CasePrize> of(LootCaseType type) {
        return CACHE.computeIfAbsent(type, CasePrizes::build);
    }

    /** Выбор приза на сервере. Возвращает индекс в списке of(type). */
    public static int roll(LootCaseType type, Random random) {
        List<CasePrize> prizes = of(type);

        if (random.nextDouble() < type.getJackpotChance()) {
            List<Integer> jackpots = new ArrayList<>();
            for (int i = 0; i < prizes.size(); i++) if (prizes.get(i).jackpot()) jackpots.add(i);
            return jackpots.get(random.nextInt(jackpots.size()));
        }

        int total = 0;
        for (CasePrize p : prizes) if (!p.jackpot()) total += p.weight();
        int roll = random.nextInt(total);
        for (int i = 0; i < prizes.size(); i++) {
            CasePrize p = prizes.get(i);
            if (p.jackpot()) continue;
            roll -= p.weight();
            if (roll < 0) return i;
        }
        return 0;
    }

    private static List<CasePrize> build(LootCaseType type) {
        List<CasePrize> list = new ArrayList<>();
        switch (type) {
            case ARMOR -> {
                addSet(list, 10, Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS);
                addSet(list, 5, Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS);
                addSet(list, 6, Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);
                addSet(list, 3, Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS);
                addSet(list, 1, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

                // Джекпот: незеритовая броня с максимальными ванильными чарами.
                list.add(CasePrize.jackpot(Items.NETHERITE_HELMET,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("respiration", 3), ench("aqua_affinity", 1), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_CHESTPLATE,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_LEGGINGS,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("swift_sneak", 3), ench("thorns", 3)));
                list.add(CasePrize.jackpot(Items.NETHERITE_BOOTS,
                        ench("protection", 4), ench("unbreaking", 3), ench("mending", 1),
                        ench("feather_falling", 4), ench("depth_strider", 3), ench("thorns", 3)));
            }
            case PICKAXE -> {
                addTools(list, Items.WOODEN_PICKAXE, Items.STONE_PICKAXE, Items.IRON_PICKAXE,
                        Items.GOLDEN_PICKAXE, Items.DIAMOND_PICKAXE);
                list.add(CasePrize.jackpot(Items.NETHERITE_PICKAXE,
                        ench("efficiency", 5), ench("unbreaking", 3), ench("fortune", 3), ench("mending", 1)));
            }
            case SWORD -> {
                addTools(list, Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD,
                        Items.GOLDEN_SWORD, Items.DIAMOND_SWORD);
                list.add(CasePrize.jackpot(Items.NETHERITE_SWORD,
                        ench("sharpness", 5), ench("unbreaking", 3), ench("looting", 3),
                        ench("fire_aspect", 2), ench("sweeping_edge", 3), ench("mending", 1)));
            }
        }
        return List.copyOf(list);
    }

    private static void addSet(List<CasePrize> list, int weight, Item... items) {
        for (Item item : items) list.add(CasePrize.normal(item, weight));
    }

    /** Веса: дерево, камень, железо, золото, алмаз. */
    private static void addTools(List<CasePrize> list, Item wood, Item stone, Item iron, Item gold, Item diamond) {
        list.add(CasePrize.normal(wood, 20));
        list.add(CasePrize.normal(stone, 30));
        list.add(CasePrize.normal(iron, 30));
        list.add(CasePrize.normal(gold, 12));
        list.add(CasePrize.normal(diamond, 8));
    }
}
